var Base = {
	year: 2012//基础年份
}

window.onload = function () {

	var _date = new Date();//当前日期对象
	var _year = _date.getFullYear();
	var _month = _date.getMonth() + 1;
	var _day = _date.getDate();

	var oUl = document.getElementsByClassName('canledar')[0];
	var oLi = oUl.getElementsByTagName('li');


	var oPreBut = document.getElementById('pre');
	var oNexBut = document.getElementById('nex');
	var selectedDay = _day;//选择的日期

	render();

	oNexBut.addEventListener('click', function () {
		if(_month < 12) {
			_month ++;
		} else {
			_year ++;
			_month = 1;
		}
		if(_year >= Base.year){oPreBut.disabled = false; }
		render();
	});

	oPreBut.addEventListener('click',function () {
		if(_month > 1){
			_month --;
		}else{
			_year --;
			_month = 12;
		}
		if(_year < Base.year){
			this.disabled = true;
		}
		render();
	});

	function defaultSelect (index, startDay) {//默认选择的日期，当月当日，其他月默认一日
		if(_month == _date.getMonth() + 1){
			index = _date.getDate() + startDay - 1;
		}
		oLi[index].classList.add('selected');
		selectedDay = index - startDay + 1;
	}

	function changeCurrDate () {//改变显示的日期
		var oShowDate = document.getElementById('show_date');
		oShowDate.innerHTML = `${_year} 年 ${_month} 月 ${selectedDay} 日`
	}

	function render () {//渲染界面

		var currMonthDay = getMonthDay(_year, _month);
		var currStartWeek = getYearDays(_year, _month-1) % 7;
		var currEndWeek = getYearDays(_year, _month) % 7;

		clear();//清除界面
		defaultSelect(currStartWeek, currStartWeek);
		changeCurrDate();

		for(let i=0; i<oLi.length; i++){//清除所有li的内容
			oLi[i].innerHTML = '';
		}
		for(let i=0; i<currMonthDay; i++){//渲染并且添加点击选中事件
			oLi[i + currStartWeek].innerHTML = i+1;
			oLi[i + currStartWeek].addEventListener('click', toggleSelect);
		}
	}

	function toggleSelect(){//点击选中
		var oUl = document.getElementsByClassName('canledar')[0];
		var oLi = oUl.getElementsByTagName('li');
		for(let i=0; i<oLi.length; i++){
			if(oLi[i].classList.contains('selected')) {
				oLi[i].classList.remove('selected');
			}
		}
		this.classList.add('selected');
		selectedDay = this.innerHTML;
		changeCurrDate();
	}

	function clear () {//清除界面和监听的事件
		for(let i=0; i<oLi.length; i++){
			if(oLi[i].classList.contains('selected')){
				oLi[i].classList.remove('selected');
			}
			oLi[i].removeEventListener('click', toggleSelect);
		}
	}
}

function getMonthDay (year,month) {//得到某年某月的天数
	return [31,null,31,30,31,30,31,31,30,31,30,31][month-1]||(isLeapYear(year) ? 29 : 28);
}

function isLeapYear (year) {//判断是否闰年
	return year%4==0&&year%100!=0||year%400==0;
		
}

function getYearDays (year,month) {//得到某年某月到基础年份的所有天数
	let dayNum = 0;
	for(let i=Base.year;i<year;i++){
		dayNum += isLeapYear(i) ? 366 : 365;
	}
	return dayNum + getMonthDays(year,month);
}

function getMonthDays (year,month) {//得到一年内到某月份的天数
	let dayNum = 0;
	for(let i=1; i<=month; i++){
		dayNum += getMonthDay(year,i);
	}
	return dayNum;
}
